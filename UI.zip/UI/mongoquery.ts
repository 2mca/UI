//m thi name chalu thatu hoy to
db.stud.find({name:{$regex:/^m/}})

//chhele m aavtu hoy to
db.stud.find({name:{$regex:/m$/}})

//vachhe game tya lin aavtu hoy to
db.stud.find({name:{$regex:/lin/}})

//line m thi start thati hoy to
db.stud.find({name:{$regex:/m/,$option:"si"}})

//sort
db.mycol.find({},{"title":1,_id:0}).sort({"title":-1}) 

//Aggregation

db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$sum : 1}}}]) 
db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$avg : "$session"}}}])
db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$min : "$session"}}}])
db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$max : "$session"}}}])

db.programmers.aggregate([{$group : {_id: "$type", TotalRecords: {$sum : 1}}}])
db.writers.aggregate([{$group:{_id:"$author",totalbook:{$sum:1}}}])

//Lowest
db.books.aggregate([{$group:{_id:"$title","total_likes":{$sum:"$likes"}}},{$sort:{"total_likes":1}},{$limit:1}])
//2nd lowest skip 1 
db.books.aggregate([{$group:{_id:"$title","total_likes":{$sum:"$likes"}}},{$sort:{"total_likes":1}},{$skip:1},{$limit:1}])
//highest
db.books.aggregate([{$group:{_id:"$title","total_likes":{$sum:"$likes"}}},{$sort:{"total_likes":-1}},{$limit:1}])
//2nd highest
db.books.aggregate([{$group:{_id:"$title","total_likes":{$sum:"$likes"}}},{$sort:{"total_likes":-1}},{$skip:1},{$limit:1}])


db.books.aggregate({$group:{_id:"$title","total_count":{$sum:"$likes"}}})
db.books.aggregate([{$match:{status:"A"}},{$group:{_id:"$title"}}])
db.books.aggregate({$group:{_id:"$title","total_likes":{$sum:"$likes"}}},{$sort:{"total_likes":1}})
db.books.aggregate({$group:{_id:"$title","total_likes":{$sum:"$likes"}}},{$match:{"total_likes":{$gt:100}}},{$sort:{"total_likes":1}})


db.books.find({$or:[{status:"A"},{status:"D"}]})
db.books.find({$and:[{title:"NodeJs"},{status:"A"}]})
db.books.find({$and:[{title:"NodeJs"},{likes:{$gt:50}}]})
