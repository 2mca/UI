import { Component, OnInit } from '@angular/core';
import { FetchdataService } from '../service/fetchdata.service';
@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  posts:any = []

  constructor(private _fetchdataservice:FetchdataService) { }

  ngOnInit(): void 
  {
    this._fetchdataservice.getPost().subscribe((data:any)=>{this.posts=data})
}
}
