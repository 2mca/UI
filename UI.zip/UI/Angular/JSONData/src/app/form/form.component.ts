import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  Email='';
  Pwd='';
  chk='';
  chkval:number=1;

  submit(login:any){
    console.log(this.Email);
    alert(this.Email);
  }
}
