import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FetchdataService {
 /*ng serve --proxy-config proxy.conf.json*/
 
  url="/api/inventories";
  constructor(private _http:HttpClient) { }
  getPost(){
    return this._http.get(this.url)
  }
}
